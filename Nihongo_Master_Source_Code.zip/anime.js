// =========================================
// DATABASE SOAL JEPANG (150 Soal Per Urutan/Kategori)
// =========================================
const quizData = {
    "hiragana": [
        {
            "question": "あ",
            "options": [
                "ha",
                "Rumah",
                "gyo",
                "a"
            ],
            "answer": "a"
        },
        {
            "question": "い",
            "options": [
                "Hujan",
                "Salju",
                "ro",
                "i"
            ],
            "answer": "i"
        },
        {
            "question": "う",
            "options": [
                "Gunung Fuji",
                "u",
                "go",
                "yu"
            ],
            "answer": "u"
        },
        {
            "question": "え",
            "options": [
                "Tiket",
                "ha",
                "e",
                "pe"
            ],
            "answer": "e"
        },
        {
            "question": "お",
            "options": [
                "Gunung",
                "gu",
                "ro",
                "o"
            ],
            "answer": "o"
        },
        {
            "question": "か",
            "options": [
                "Guru",
                "cha",
                "se",
                "ka"
            ],
            "answer": "ka"
        },
        {
            "question": "き",
            "options": [
                "hya",
                "sha",
                "ke",
                "ki"
            ],
            "answer": "ki"
        },
        {
            "question": "く",
            "options": [
                "bu",
                "ya",
                "ku",
                "zu(du)"
            ],
            "answer": "ku"
        },
        {
            "question": "け",
            "options": [
                "bya",
                "kya",
                "kyo",
                "ke"
            ],
            "answer": "ke"
        },
        {
            "question": "こ",
            "options": [
                "yo",
                "pa",
                "ko",
                "n"
            ],
            "answer": "ko"
        },
        {
            "question": "さ",
            "options": [
                "Salju",
                "sa",
                "Koran",
                "su"
            ],
            "answer": "sa"
        },
        {
            "question": "し",
            "options": [
                "Tiket",
                "shi",
                "mu",
                "he"
            ],
            "answer": "shi"
        },
        {
            "question": "す",
            "options": [
                "su",
                "pyo",
                "jo",
                "so"
            ],
            "answer": "su"
        },
        {
            "question": "せ",
            "options": [
                "nya",
                "ni",
                "se",
                "de"
            ],
            "answer": "se"
        },
        {
            "question": "そ",
            "options": [
                "Kota",
                "so",
                "be",
                "Bunga"
            ],
            "answer": "so"
        },
        {
            "question": "た",
            "options": [
                "ta",
                "cha",
                "Selamat pagi",
                "Bunga"
            ],
            "answer": "ta"
        },
        {
            "question": "ち",
            "options": [
                "Buku",
                "sha",
                "chi",
                "Telepon"
            ],
            "answer": "chi"
        },
        {
            "question": "つ",
            "options": [
                "a",
                "Stasiun",
                "ka",
                "tsu"
            ],
            "answer": "tsu"
        },
        {
            "question": "て",
            "options": [
                "Rumah",
                "te",
                "ze",
                "Kuda"
            ],
            "answer": "te"
        },
        {
            "question": "と",
            "options": [
                "Burung",
                "he",
                "to",
                "Salju"
            ],
            "answer": "to"
        },
        {
            "question": "な",
            "options": [
                "no",
                "Kamera",
                "na",
                "Jam"
            ],
            "answer": "na"
        },
        {
            "question": "に",
            "options": [
                "ni",
                "Stasiun",
                "Salju",
                "e"
            ],
            "answer": "ni"
        },
        {
            "question": "ぬ",
            "options": [
                "yo",
                "ki",
                "nu",
                "zu(du)"
            ],
            "answer": "nu"
        },
        {
            "question": "ね",
            "options": [
                "Bunga Sakura",
                "Teman",
                "ne",
                "cho"
            ],
            "answer": "ne"
        },
        {
            "question": "の",
            "options": [
                "no",
                "ka",
                "ho",
                "pya"
            ],
            "answer": "no"
        },
        {
            "question": "は",
            "options": [
                "nyo",
                "mu",
                "ra",
                "ha"
            ],
            "answer": "ha"
        },
        {
            "question": "ひ",
            "options": [
                "gyu",
                "pu",
                "na",
                "hi"
            ],
            "answer": "hi"
        },
        {
            "question": "ふ",
            "options": [
                "te",
                "Terima kasih",
                "ryu",
                "fu"
            ],
            "answer": "fu"
        },
        {
            "question": "へ",
            "options": [
                "a",
                "he",
                "zu(du)",
                "Kereta api"
            ],
            "answer": "he"
        },
        {
            "question": "ほ",
            "options": [
                "wo",
                "pyo",
                "o",
                "ho"
            ],
            "answer": "ho"
        },
        {
            "question": "ま",
            "options": [
                "nyu",
                "ho",
                "Uang",
                "ma"
            ],
            "answer": "ma"
        },
        {
            "question": "み",
            "options": [
                "de",
                "e",
                "Bahasa Inggris",
                "mi"
            ],
            "answer": "mi"
        },
        {
            "question": "む",
            "options": [
                "Surat",
                "ja",
                "Guru",
                "mu"
            ],
            "answer": "mu"
        },
        {
            "question": "め",
            "options": [
                "da",
                "me",
                "pi",
                "Guru"
            ],
            "answer": "me"
        },
        {
            "question": "も",
            "options": [
                "mo",
                "e",
                "hyo",
                "ba"
            ],
            "answer": "mo"
        },
        {
            "question": "や",
            "options": [
                "ta",
                "Bunga",
                "ma",
                "ya"
            ],
            "answer": "ya"
        },
        {
            "question": "ゆ",
            "options": [
                "kya",
                "yu",
                "he",
                "ra"
            ],
            "answer": "yu"
        },
        {
            "question": "よ",
            "options": [
                "myo",
                "pa",
                "sa",
                "yo"
            ],
            "answer": "yo"
        },
        {
            "question": "ら",
            "options": [
                "yu",
                "nyo",
                "ra",
                "go"
            ],
            "answer": "ra"
        },
        {
            "question": "り",
            "options": [
                "ri",
                "hya",
                "ne",
                "ba"
            ],
            "answer": "ri"
        },
        {
            "question": "る",
            "options": [
                "nyu",
                "zu(du)",
                "bo",
                "ru"
            ],
            "answer": "ru"
        },
        {
            "question": "れ",
            "options": [
                "e",
                "ho",
                "se",
                "re"
            ],
            "answer": "re"
        },
        {
            "question": "ろ",
            "options": [
                "ro",
                "myo",
                "rya",
                "nu"
            ],
            "answer": "ro"
        },
        {
            "question": "わ",
            "options": [
                "Sepatu",
                "wa",
                "ba",
                "Jepang"
            ],
            "answer": "wa"
        },
        {
            "question": "を",
            "options": [
                "ya",
                "Kuda",
                "chi",
                "wo"
            ],
            "answer": "wo"
        },
        {
            "question": "ん",
            "options": [
                "yo",
                "fu",
                "Siswa",
                "n"
            ],
            "answer": "n"
        },
        {
            "question": "が",
            "options": [
                "ga",
                "Gunung",
                "Ikan",
                "Laut"
            ],
            "answer": "ga"
        },
        {
            "question": "ぎ",
            "options": [
                "Air",
                "Bunga Sakura",
                "zo",
                "gi"
            ],
            "answer": "gi"
        },
        {
            "question": "ぐ",
            "options": [
                "Uang",
                "gu",
                "gya",
                "ma"
            ],
            "answer": "gu"
        },
        {
            "question": "げ",
            "options": [
                "e",
                "ryo",
                "za",
                "ge"
            ],
            "answer": "ge"
        },
        {
            "question": "ご",
            "options": [
                "Tiket",
                "nyo",
                "go",
                "zu"
            ],
            "answer": "go"
        },
        {
            "question": "ざ",
            "options": [
                "Kamera",
                "wa",
                "za",
                "Anjing"
            ],
            "answer": "za"
        },
        {
            "question": "じ",
            "options": [
                "Komputer/Laptop",
                "i",
                "Stasiun",
                "ji"
            ],
            "answer": "ji"
        },
        {
            "question": "ず",
            "options": [
                "Koran",
                "pe",
                "zu",
                "kya"
            ],
            "answer": "zu"
        },
        {
            "question": "ぜ",
            "options": [
                "Majalah",
                "Sungai",
                "ze",
                "bi"
            ],
            "answer": "ze"
        },
        {
            "question": "ぞ",
            "options": [
                "pi",
                "Kamar",
                "Tiket",
                "zo"
            ],
            "answer": "zo"
        },
        {
            "question": "だ",
            "options": [
                "do",
                "da",
                "cho",
                "Ikan"
            ],
            "answer": "da"
        },
        {
            "question": "ぢ",
            "options": [
                "nyu",
                "Anjing",
                "ju",
                "ji(di)"
            ],
            "answer": "ji(di)"
        },
        {
            "question": "づ",
            "options": [
                "hyo",
                "zu(du)",
                "Buku",
                "Kamera"
            ],
            "answer": "zu(du)"
        },
        {
            "question": "で",
            "options": [
                "de",
                "Sepatu",
                "ho",
                "to"
            ],
            "answer": "de"
        },
        {
            "question": "ど",
            "options": [
                "Kamera",
                "do",
                "Majalah",
                "yo"
            ],
            "answer": "do"
        },
        {
            "question": "ば",
            "options": [
                "ba",
                "Kamera",
                "pa",
                "na"
            ],
            "answer": "ba"
        },
        {
            "question": "び",
            "options": [
                "Sushi",
                "Burung",
                "Kamera",
                "bi"
            ],
            "answer": "bi"
        },
        {
            "question": "ぶ",
            "options": [
                "nu",
                "ju",
                "bu",
                "Koran"
            ],
            "answer": "bu"
        },
        {
            "question": "べ",
            "options": [
                "be",
                "mi",
                "kyo",
                "kyu"
            ],
            "answer": "be"
        },
        {
            "question": "ぼ",
            "options": [
                "ru",
                "bo",
                "ga",
                "i"
            ],
            "answer": "bo"
        },
        {
            "question": "ぱ",
            "options": [
                "ni",
                "pa",
                "pu",
                "bu"
            ],
            "answer": "pa"
        },
        {
            "question": "ぴ",
            "options": [
                "Guru",
                "pi",
                "na",
                "ja"
            ],
            "answer": "pi"
        },
        {
            "question": "ぷ",
            "options": [
                "pyu",
                "Bunga",
                "mu",
                "pu"
            ],
            "answer": "pu"
        },
        {
            "question": "ぺ",
            "options": [
                "pe",
                "Tiket",
                "gi",
                "ko"
            ],
            "answer": "pe"
        },
        {
            "question": "ぽ",
            "options": [
                "bi",
                "po",
                "Siswa",
                "mo"
            ],
            "answer": "po"
        },
        {
            "question": "きゃ",
            "options": [
                "no",
                "yo",
                "zu",
                "kya"
            ],
            "answer": "kya"
        },
        {
            "question": "きゅ",
            "options": [
                "shi",
                "do",
                "ze",
                "kyu"
            ],
            "answer": "kyu"
        },
        {
            "question": "きょ",
            "options": [
                "a",
                "Laut",
                "kyo",
                "za"
            ],
            "answer": "kyo"
        },
        {
            "question": "しゃ",
            "options": [
                "shu",
                "nyo",
                "sha",
                "ni"
            ],
            "answer": "sha"
        },
        {
            "question": "しゅ",
            "options": [
                "ji",
                "shu",
                "ba",
                "go"
            ],
            "answer": "shu"
        },
        {
            "question": "しょ",
            "options": [
                "kyo",
                "sho",
                "ki",
                "ko"
            ],
            "answer": "sho"
        },
        {
            "question": "ちゃ",
            "options": [
                "ru",
                "Hujan",
                "Uang",
                "cha"
            ],
            "answer": "cha"
        },
        {
            "question": "ちゅ",
            "options": [
                "gu",
                "chu",
                "do",
                "re"
            ],
            "answer": "chu"
        },
        {
            "question": "ちょ",
            "options": [
                "pu",
                "cho",
                "gya",
                "bu"
            ],
            "answer": "cho"
        },
        {
            "question": "にゃ",
            "options": [
                "nya",
                "Terima kasih",
                "Stasiun",
                "gyo"
            ],
            "answer": "nya"
        },
        {
            "question": "にゅ",
            "options": [
                "ko",
                "nyu",
                "Buku",
                "mya"
            ],
            "answer": "nyu"
        },
        {
            "question": "にょ",
            "options": [
                "nyo",
                "nya",
                "myo",
                "gyu"
            ],
            "answer": "nyo"
        },
        {
            "question": "ひゃ",
            "options": [
                "hyo",
                "nya",
                "chu",
                "hya"
            ],
            "answer": "hya"
        },
        {
            "question": "ひゅ",
            "options": [
                "cho",
                "pi",
                "hyu",
                "hya"
            ],
            "answer": "hyu"
        },
        {
            "question": "ひょ",
            "options": [
                "Siswa",
                "Kamar",
                "hyo",
                "te"
            ],
            "answer": "hyo"
        },
        {
            "question": "みゃ",
            "options": [
                "u",
                "ji(di)",
                "ga",
                "mya"
            ],
            "answer": "mya"
        },
        {
            "question": "みゅ",
            "options": [
                "myu",
                "Kuda",
                "Sushi",
                "sha"
            ],
            "answer": "myu"
        },
        {
            "question": "みょ",
            "options": [
                "myo",
                "Tas",
                "su",
                "Siswa"
            ],
            "answer": "myo"
        },
        {
            "question": "りゃ",
            "options": [
                "rya",
                "bya",
                "a",
                "su"
            ],
            "answer": "rya"
        },
        {
            "question": "りゅ",
            "options": [
                "nyo",
                "chi",
                "shi",
                "ryu"
            ],
            "answer": "ryu"
        },
        {
            "question": "りょ",
            "options": [
                "ryo",
                "ma",
                "so",
                "ja"
            ],
            "answer": "ryo"
        },
        {
            "question": "ぎゃ",
            "options": [
                "Guru",
                "ga",
                "gya",
                "Komputer/Laptop"
            ],
            "answer": "gya"
        },
        {
            "question": "ぎゅ",
            "options": [
                "cho",
                "Kuda",
                "gyu",
                "pyo"
            ],
            "answer": "gyu"
        },
        {
            "question": "ぎょ",
            "options": [
                "ki",
                "Angin",
                "ji(di)",
                "gyo"
            ],
            "answer": "gyo"
        },
        {
            "question": "じゃ",
            "options": [
                "Majalah",
                "ja",
                "mu",
                "ku"
            ],
            "answer": "ja"
        },
        {
            "question": "じゅ",
            "options": [
                "Kuda",
                "ju",
                "Burung",
                "Tiket"
            ],
            "answer": "ju"
        },
        {
            "question": "じょ",
            "options": [
                "jo",
                "za",
                "hya",
                "ge"
            ],
            "answer": "jo"
        },
        {
            "question": "びゃ",
            "options": [
                "mya",
                "Guru",
                "bya",
                "Gunung Fuji"
            ],
            "answer": "bya"
        },
        {
            "question": "びゅ",
            "options": [
                "Jam",
                "a",
                "ko",
                "byu"
            ],
            "answer": "byu"
        },
        {
            "question": "びょ",
            "options": [
                "myu",
                "ju",
                "byo",
                "Sungai"
            ],
            "answer": "byo"
        },
        {
            "question": "ぴゃ",
            "options": [
                "mya",
                "be",
                "pya",
                "Majalah"
            ],
            "answer": "pya"
        },
        {
            "question": "ぴゅ",
            "options": [
                "za",
                "pyu",
                "ke",
                "so"
            ],
            "answer": "pyu"
        },
        {
            "question": "ぴょ",
            "options": [
                "Terima kasih",
                "Selamat tinggal",
                "pyo",
                "Tas"
            ],
            "answer": "pyo"
        },
        {
            "question": "ありがとう",
            "options": [
                "Tiket",
                "no",
                "nu",
                "Terima kasih"
            ],
            "answer": "Terima kasih"
        },
        {
            "question": "こんにちは",
            "options": [
                "ni",
                "ru",
                "Halo / Selamat siang",
                "cho"
            ],
            "answer": "Halo / Selamat siang"
        },
        {
            "question": "さようなら",
            "options": [
                "Kuda",
                "Selamat tinggal",
                "mu",
                "mya"
            ],
            "answer": "Selamat tinggal"
        },
        {
            "question": "すし",
            "options": [
                "zo",
                "sa",
                "Sushi",
                "gya"
            ],
            "answer": "Sushi"
        },
        {
            "question": "てんぷら",
            "options": [
                "byu",
                "Tempura",
                "ya",
                "mu"
            ],
            "answer": "Tempura"
        },
        {
            "question": "さくら",
            "options": [
                "Buku",
                "hya",
                "Bunga Sakura",
                "ja"
            ],
            "answer": "Bunga Sakura"
        },
        {
            "question": "ふじさん",
            "options": [
                "chu",
                "myu",
                "Kucing",
                "Gunung Fuji"
            ],
            "answer": "Gunung Fuji"
        },
        {
            "question": "ねこ",
            "options": [
                "ma",
                "Kucing",
                "Tiket",
                "bo"
            ],
            "answer": "Kucing"
        },
        {
            "question": "いぬ",
            "options": [
                "Pohon",
                "hya",
                "Anjing",
                "tsu"
            ],
            "answer": "Anjing"
        },
        {
            "question": "うま",
            "options": [
                "Kuda",
                "ryo",
                "nya",
                "Teman"
            ],
            "answer": "Kuda"
        },
        {
            "question": "とり",
            "options": [
                "Gunung Fuji",
                "Hujan",
                "Burung",
                "mi"
            ],
            "answer": "Burung"
        },
        {
            "question": "さかな",
            "options": [
                "Ikan",
                "n",
                "ro",
                "Air"
            ],
            "answer": "Ikan"
        },
        {
            "question": "はな",
            "options": [
                "ya",
                "ba",
                "Bunga",
                "no"
            ],
            "answer": "Bunga"
        },
        {
            "question": "みず",
            "options": [
                "Air",
                "kya",
                "ba",
                "Sepatu"
            ],
            "answer": "Air"
        },
        {
            "question": "やま",
            "options": [
                "Gunung Fuji",
                "go",
                "ba",
                "Gunung"
            ],
            "answer": "Gunung"
        },
        {
            "question": "かわ",
            "options": [
                "ne",
                "pe",
                "hya",
                "Sungai"
            ],
            "answer": "Sungai"
        },
        {
            "question": "うみ",
            "options": [
                "pyo",
                "ja",
                "n",
                "Laut"
            ],
            "answer": "Laut"
        },
        {
            "question": "そら",
            "options": [
                "zu(du)",
                "nya",
                "Langit",
                "ka"
            ],
            "answer": "Langit"
        },
        {
            "question": "かぜ",
            "options": [
                "Angin",
                "shu",
                "na",
                "ji(di)"
            ],
            "answer": "Angin"
        },
        {
            "question": "あめ",
            "options": [
                "Tiket",
                "Hujan",
                "fu",
                "no"
            ],
            "answer": "Hujan"
        },
        {
            "question": "ゆき",
            "options": [
                "Majalah",
                "cho",
                "Salju",
                "za"
            ],
            "answer": "Salju"
        },
        {
            "question": "き",
            "options": [
                "Pohon",
                "no",
                "bi",
                "ki"
            ],
            "answer": "Pohon"
        },
        {
            "question": "くるま",
            "options": [
                "pyu",
                "Mobil",
                "ku",
                "de"
            ],
            "answer": "Mobil"
        },
        {
            "question": "でんしゃ",
            "options": [
                "Gunung Fuji",
                "to",
                "Kereta api",
                "go"
            ],
            "answer": "Kereta api"
        },
        {
            "question": "えき",
            "options": [
                "chi",
                "ta",
                "Stasiun",
                "byu"
            ],
            "answer": "Stasiun"
        },
        {
            "question": "まち",
            "options": [
                "ju",
                "zu",
                "ya",
                "Kota"
            ],
            "answer": "Kota"
        },
        {
            "question": "いえ",
            "options": [
                "Rumah",
                "Terima kasih",
                "Gunung",
                "Pohon"
            ],
            "answer": "Rumah"
        },
        {
            "question": "へや",
            "options": [
                "su",
                "Uang",
                "Kereta api",
                "Kamar"
            ],
            "answer": "Kamar"
        },
        {
            "question": "ともだち",
            "options": [
                "myu",
                "sho",
                "Teman",
                "da"
            ],
            "answer": "Teman"
        },
        {
            "question": "せんせい",
            "options": [
                "ku",
                "shu",
                "Guru",
                "ba"
            ],
            "answer": "Guru"
        },
        {
            "question": "がくせい",
            "options": [
                "jo",
                "Siswa",
                "Kereta api",
                "tsu"
            ],
            "answer": "Siswa"
        },
        {
            "question": "にほん",
            "options": [
                "Teman",
                "be",
                "chu",
                "Jepang"
            ],
            "answer": "Jepang"
        },
        {
            "question": "えいご",
            "options": [
                "Halo / Selamat siang",
                "cha",
                "Bahasa Inggris",
                "Hujan"
            ],
            "answer": "Bahasa Inggris"
        },
        {
            "question": "ほん",
            "options": [
                "Bunga Sakura",
                "Buku",
                "be",
                "kyu"
            ],
            "answer": "Buku"
        },
        {
            "question": "とけい",
            "options": [
                "Jam",
                "da",
                "bu",
                "sa"
            ],
            "answer": "Jam"
        },
        {
            "question": "かばん",
            "options": [
                "Tas",
                "Laut",
                "mu",
                "be"
            ],
            "answer": "Tas"
        },
        {
            "question": "くつ",
            "options": [
                "se",
                "Sepatu",
                "pi",
                "pyu"
            ],
            "answer": "Sepatu"
        },
        {
            "question": "しんぶん",
            "options": [
                "myo",
                "Teman",
                "Koran",
                "ke"
            ],
            "answer": "Koran"
        },
        {
            "question": "ざっし",
            "options": [
                "Majalah",
                "Selamat tinggal",
                "gyo",
                "ne"
            ],
            "answer": "Majalah"
        },
        {
            "question": "てがみ",
            "options": [
                "Telepon",
                "ba",
                "hi",
                "Surat"
            ],
            "answer": "Surat"
        },
        {
            "question": "でんわ",
            "options": [
                "Kamera",
                "byo",
                "Telepon",
                "pa"
            ],
            "answer": "Telepon"
        },
        {
            "question": "ぱそこん",
            "options": [
                "bya",
                "Halo / Selamat siang",
                "ju",
                "Komputer/Laptop"
            ],
            "answer": "Komputer/Laptop"
        },
        {
            "question": "かめら",
            "options": [
                "Mobil",
                "Kamera",
                "Rumah",
                "Burung"
            ],
            "answer": "Kamera"
        },
        {
            "question": "おかね",
            "options": [
                "hya",
                "bo",
                "Kucing",
                "Uang"
            ],
            "answer": "Uang"
        },
        {
            "question": "きっぷ",
            "options": [
                "go",
                "Buku",
                "Tiket",
                "Bunga"
            ],
            "answer": "Tiket"
        },
        {
            "question": "おはよう",
            "options": [
                "sha",
                "de",
                "Selamat pagi",
                "myu"
            ],
            "answer": "Selamat pagi"
        }
    ],
    "katakana": [
        {
            "question": "ア",
            "options": [
                "ni",
                "a",
                "Anime",
                "kya"
            ],
            "answer": "a"
        },
        {
            "question": "イ",
            "options": [
                "Kamera",
                "Kemeja",
                "hi",
                "i"
            ],
            "answer": "i"
        },
        {
            "question": "ウ",
            "options": [
                "ka",
                "nyo",
                "nya",
                "u"
            ],
            "answer": "u"
        },
        {
            "question": "エ",
            "options": [
                "yo",
                "ro",
                "Kopi",
                "e"
            ],
            "answer": "e"
        },
        {
            "question": "オ",
            "options": [
                "o",
                "sa",
                "Kamera",
                "Game"
            ],
            "answer": "o"
        },
        {
            "question": "カ",
            "options": [
                "za",
                "o",
                "Steak",
                "ka"
            ],
            "answer": "ka"
        },
        {
            "question": "キ",
            "options": [
                "zo",
                "Roti",
                "gyu",
                "ki"
            ],
            "answer": "ki"
        },
        {
            "question": "ク",
            "options": [
                "Jeruk",
                "ku",
                "chu",
                "hyu"
            ],
            "answer": "ku"
        },
        {
            "question": "ケ",
            "options": [
                "ke",
                "ryo",
                "mu",
                "Televisi"
            ],
            "answer": "ke"
        },
        {
            "question": "コ",
            "options": [
                "myu",
                "Kue",
                "ko",
                "nu"
            ],
            "answer": "ko"
        },
        {
            "question": "サ",
            "options": [
                "Dasi",
                "Selada",
                "sa",
                "byo"
            ],
            "answer": "sa"
        },
        {
            "question": "シ",
            "options": [
                "hyu",
                "myo",
                "o",
                "shi"
            ],
            "answer": "shi"
        },
        {
            "question": "ス",
            "options": [
                "Korek api",
                "Selada",
                "byu",
                "su"
            ],
            "answer": "su"
        },
        {
            "question": "セ",
            "options": [
                "rya",
                "se",
                "ze",
                "Pisang"
            ],
            "answer": "se"
        },
        {
            "question": "ソ",
            "options": [
                "ki",
                "ka",
                "Pisang",
                "so"
            ],
            "answer": "so"
        },
        {
            "question": "タ",
            "options": [
                "kyo",
                "gyu",
                "ta",
                "n"
            ],
            "answer": "ta"
        },
        {
            "question": "チ",
            "options": [
                "n",
                "i",
                "chi",
                "gu"
            ],
            "answer": "chi"
        },
        {
            "question": "ツ",
            "options": [
                "ha",
                "Manga",
                "Dasi",
                "tsu"
            ],
            "answer": "tsu"
        },
        {
            "question": "テ",
            "options": [
                "ma",
                "ze",
                "Melon",
                "te"
            ],
            "answer": "te"
        },
        {
            "question": "ト",
            "options": [
                "to",
                "u",
                "Jazz",
                "wo"
            ],
            "answer": "to"
        },
        {
            "question": "ナ",
            "options": [
                "ra",
                "na",
                "ryu",
                "mya"
            ],
            "answer": "na"
        },
        {
            "question": "ニ",
            "options": [
                "tsu",
                "ni",
                "pyu",
                "myo"
            ],
            "answer": "ni"
        },
        {
            "question": "ヌ",
            "options": [
                "nu",
                "myu",
                "ji(di)",
                "po"
            ],
            "answer": "nu"
        },
        {
            "question": "ネ",
            "options": [
                "kya",
                "ka",
                "Toilet",
                "ne"
            ],
            "answer": "ne"
        },
        {
            "question": "ノ",
            "options": [
                "go",
                "ke",
                "re",
                "no"
            ],
            "answer": "no"
        },
        {
            "question": "ハ",
            "options": [
                "ryu",
                "ha",
                "gyu",
                "se"
            ],
            "answer": "ha"
        },
        {
            "question": "ヒ",
            "options": [
                "Buku catatan",
                "Kelas",
                "zu",
                "hi"
            ],
            "answer": "hi"
        },
        {
            "question": "フ",
            "options": [
                "Dasi",
                "fu",
                "kya",
                "Gitar"
            ],
            "answer": "fu"
        },
        {
            "question": "ヘ",
            "options": [
                "Piano",
                "he",
                "kyo",
                "pa"
            ],
            "answer": "he"
        },
        {
            "question": "ホ",
            "options": [
                "ho",
                "nyu",
                "ka",
                "no"
            ],
            "answer": "ho"
        },
        {
            "question": "マ",
            "options": [
                "ma",
                "ki",
                "ru",
                "do"
            ],
            "answer": "ma"
        },
        {
            "question": "ミ",
            "options": [
                "Roti",
                "chu",
                "Komputer/Laptop",
                "mi"
            ],
            "answer": "mi"
        },
        {
            "question": "ム",
            "options": [
                "so",
                "chu",
                "Steak",
                "mu"
            ],
            "answer": "mu"
        },
        {
            "question": "メ",
            "options": [
                "te",
                "bya",
                "me",
                "mo"
            ],
            "answer": "me"
        },
        {
            "question": "モ",
            "options": [
                "pi",
                "Golf",
                "ji(di)",
                "mo"
            ],
            "answer": "mo"
        },
        {
            "question": "ヤ",
            "options": [
                "jo",
                "ryu",
                "pi",
                "ya"
            ],
            "answer": "ya"
        },
        {
            "question": "ユ",
            "options": [
                "re",
                "yu",
                "be",
                "Restoran"
            ],
            "answer": "yu"
        },
        {
            "question": "ヨ",
            "options": [
                "yo",
                "shu",
                "ba",
                "myu"
            ],
            "answer": "yo"
        },
        {
            "question": "ラ",
            "options": [
                "Jazz",
                "ta",
                "go",
                "ra"
            ],
            "answer": "ra"
        },
        {
            "question": "リ",
            "options": [
                "ri",
                "te",
                "Sup",
                "no"
            ],
            "answer": "ri"
        },
        {
            "question": "ル",
            "options": [
                "nu",
                "ru",
                "bya",
                "ha"
            ],
            "answer": "ru"
        },
        {
            "question": "レ",
            "options": [
                "yo",
                "ryu",
                "re",
                "Kemeja"
            ],
            "answer": "re"
        },
        {
            "question": "ロ",
            "options": [
                "ro",
                "u",
                "ki",
                "pe"
            ],
            "answer": "ro"
        },
        {
            "question": "ワ",
            "options": [
                "pyu",
                "wa",
                "o",
                "ga"
            ],
            "answer": "wa"
        },
        {
            "question": "ヲ",
            "options": [
                "chi",
                "Amerika",
                "Piano",
                "wo"
            ],
            "answer": "wo"
        },
        {
            "question": "ン",
            "options": [
                "ma",
                "n",
                "ba",
                "Tenis"
            ],
            "answer": "n"
        },
        {
            "question": "ガ",
            "options": [
                "go",
                "ga",
                "Tenis",
                "ji"
            ],
            "answer": "ga"
        },
        {
            "question": "ギ",
            "options": [
                "ro",
                "gi",
                "Kerja paruh waktu",
                "zo"
            ],
            "answer": "gi"
        },
        {
            "question": "グ",
            "options": [
                "shi",
                "u",
                "Televisi",
                "gu"
            ],
            "answer": "gu"
        },
        {
            "question": "ゲ",
            "options": [
                "Golf",
                "ni",
                "ge",
                "Toilet"
            ],
            "answer": "ge"
        },
        {
            "question": "ゴ",
            "options": [
                "ya",
                "go",
                "Susu",
                "hyo"
            ],
            "answer": "go"
        },
        {
            "question": "ザ",
            "options": [
                "ru",
                "za",
                "go",
                "pya"
            ],
            "answer": "za"
        },
        {
            "question": "ジ",
            "options": [
                "Sepatu",
                "Tenis",
                "gi",
                "ji"
            ],
            "answer": "ji"
        },
        {
            "question": "ズ",
            "options": [
                "Roti",
                "ge",
                "Cokelat",
                "zu"
            ],
            "answer": "zu"
        },
        {
            "question": "ゼ",
            "options": [
                "ru",
                "u",
                "ze",
                "ma"
            ],
            "answer": "ze"
        },
        {
            "question": "ゾ",
            "options": [
                "o",
                "ja",
                "zo",
                "cha"
            ],
            "answer": "zo"
        },
        {
            "question": "ダ",
            "options": [
                "chu",
                "shu",
                "da",
                "Sepak bola"
            ],
            "answer": "da"
        },
        {
            "question": "ヂ",
            "options": [
                "Golf",
                "ryo",
                "ji(di)",
                "shu"
            ],
            "answer": "ji(di)"
        },
        {
            "question": "ヅ",
            "options": [
                "nyu",
                "Cokelat",
                "Komputer/Laptop",
                "zu(du)"
            ],
            "answer": "zu(du)"
        },
        {
            "question": "デ",
            "options": [
                "de",
                "pe",
                "Susu",
                "Radio"
            ],
            "answer": "de"
        },
        {
            "question": "ド",
            "options": [
                "jo",
                "go",
                "Tempat tidur",
                "do"
            ],
            "answer": "do"
        },
        {
            "question": "バ",
            "options": [
                "Korek api",
                "ba",
                "ku",
                "n"
            ],
            "answer": "ba"
        },
        {
            "question": "ビ",
            "options": [
                "Kopi",
                "bi",
                "Korek api",
                "jo"
            ],
            "answer": "bi"
        },
        {
            "question": "ブ",
            "options": [
                "su",
                "bu",
                "Kamera",
                "gi"
            ],
            "answer": "bu"
        },
        {
            "question": "ベ",
            "options": [
                "be",
                "te",
                "Restoran",
                "Kemeja"
            ],
            "answer": "be"
        },
        {
            "question": "ボ",
            "options": [
                "bo",
                "ki",
                "sho",
                "ga"
            ],
            "answer": "bo"
        },
        {
            "question": "パ",
            "options": [
                "Hotel",
                "pa",
                "a",
                "ryu"
            ],
            "answer": "pa"
        },
        {
            "question": "ピ",
            "options": [
                "hyu",
                "nya",
                "na",
                "pi"
            ],
            "answer": "pi"
        },
        {
            "question": "プ",
            "options": [
                "pu",
                "i",
                "to",
                "n"
            ],
            "answer": "pu"
        },
        {
            "question": "ペ",
            "options": [
                "he",
                "Kue",
                "Manga",
                "pe"
            ],
            "answer": "pe"
        },
        {
            "question": "ポ",
            "options": [
                "ryo",
                "po",
                "cho",
                "bo"
            ],
            "answer": "po"
        },
        {
            "question": "キャ",
            "options": [
                "pi",
                "kya",
                "mu",
                "shi"
            ],
            "answer": "kya"
        },
        {
            "question": "キュ",
            "options": [
                "kyu",
                "mya",
                "Kemeja",
                "Kamera"
            ],
            "answer": "kyu"
        },
        {
            "question": "キョ",
            "options": [
                "myo",
                "myu",
                "ji(di)",
                "kyo"
            ],
            "answer": "kyo"
        },
        {
            "question": "シャ",
            "options": [
                "zu",
                "nu",
                "sha",
                "Selada"
            ],
            "answer": "sha"
        },
        {
            "question": "シュ",
            "options": [
                "bo",
                "ta",
                "kyo",
                "shu"
            ],
            "answer": "shu"
        },
        {
            "question": "ショ",
            "options": [
                "te",
                "sho",
                "Game",
                "Steak"
            ],
            "answer": "sho"
        },
        {
            "question": "チャ",
            "options": [
                "mi",
                "cha",
                "Korek api",
                "u"
            ],
            "answer": "cha"
        },
        {
            "question": "チュ",
            "options": [
                "Sup",
                "sha",
                "chu",
                "Melon"
            ],
            "answer": "chu"
        },
        {
            "question": "チョ",
            "options": [
                "cho",
                "Kamera",
                "Jus",
                "za"
            ],
            "answer": "cho"
        },
        {
            "question": "ニャ",
            "options": [
                "de",
                "byo",
                "nya",
                "yu"
            ],
            "answer": "nya"
        },
        {
            "question": "ニュ",
            "options": [
                "sa",
                "n",
                "no",
                "nyu"
            ],
            "answer": "nyu"
        },
        {
            "question": "ニョ",
            "options": [
                "wa",
                "do",
                "go",
                "nyo"
            ],
            "answer": "nyo"
        },
        {
            "question": "ヒャ",
            "options": [
                "Toilet",
                "to",
                "hya",
                "pu"
            ],
            "answer": "hya"
        },
        {
            "question": "ヒュ",
            "options": [
                "ja",
                "pi",
                "nyu",
                "hyu"
            ],
            "answer": "hyu"
        },
        {
            "question": "ヒョ",
            "options": [
                "be",
                "shi",
                "Dasi",
                "hyo"
            ],
            "answer": "hyo"
        },
        {
            "question": "ミャ",
            "options": [
                "Sup",
                "mya",
                "so",
                "pu"
            ],
            "answer": "mya"
        },
        {
            "question": "ミュ",
            "options": [
                "ba",
                "Restoran",
                "kyo",
                "myu"
            ],
            "answer": "myu"
        },
        {
            "question": "ミョ",
            "options": [
                "myo",
                "nu",
                "Pisang",
                "n"
            ],
            "answer": "myo"
        },
        {
            "question": "リャ",
            "options": [
                "pi",
                "mo",
                "rya",
                "pyo"
            ],
            "answer": "rya"
        },
        {
            "question": "リュ",
            "options": [
                "u",
                "Cokelat",
                "mo",
                "ryu"
            ],
            "answer": "ryu"
        },
        {
            "question": "リョ",
            "options": [
                "Laporan",
                "na",
                "ryo",
                "zo"
            ],
            "answer": "ryo"
        },
        {
            "question": "ギャ",
            "options": [
                "so",
                "zo",
                "gya",
                "ta"
            ],
            "answer": "gya"
        },
        {
            "question": "ギュ",
            "options": [
                "nu",
                "gyu",
                "se",
                "gyo"
            ],
            "answer": "gyu"
        },
        {
            "question": "ギョ",
            "options": [
                "to",
                "Melon",
                "gyo",
                "Kelas"
            ],
            "answer": "gyo"
        },
        {
            "question": "ジャ",
            "options": [
                "a",
                "ja",
                "Buku catatan",
                "hyo"
            ],
            "answer": "ja"
        },
        {
            "question": "ジュ",
            "options": [
                "Piano",
                "fu",
                "ju",
                "na"
            ],
            "answer": "ju"
        },
        {
            "question": "ジョ",
            "options": [
                "Kamera",
                "Kopi",
                "jo",
                "shu"
            ],
            "answer": "jo"
        },
        {
            "question": "ビャ",
            "options": [
                "Sepatu",
                "i",
                "bya",
                "Ski"
            ],
            "answer": "bya"
        },
        {
            "question": "ビュ",
            "options": [
                "sa",
                "byu",
                "Steak",
                "sho"
            ],
            "answer": "byu"
        },
        {
            "question": "ビョ",
            "options": [
                "byo",
                "Anime",
                "shu",
                "ji"
            ],
            "answer": "byo"
        },
        {
            "question": "ピャ",
            "options": [
                "Ujian/Tes",
                "chu",
                "pya",
                "ryo"
            ],
            "answer": "pya"
        },
        {
            "question": "ピュ",
            "options": [
                "wo",
                "gyu",
                "ha",
                "pyu"
            ],
            "answer": "pyu"
        },
        {
            "question": "ピョ",
            "options": [
                "rya",
                "gya",
                "pyo",
                "he"
            ],
            "answer": "pyo"
        },
        {
            "question": "アメリカ",
            "options": [
                "Komputer/Laptop",
                "ja",
                "Amerika",
                "sa"
            ],
            "answer": "Amerika"
        },
        {
            "question": "テレビ",
            "options": [
                "Manga",
                "ka",
                "Televisi",
                "ju"
            ],
            "answer": "Televisi"
        },
        {
            "question": "ラジオ",
            "options": [
                "do",
                "pyo",
                "Amerika",
                "Radio"
            ],
            "answer": "Radio"
        },
        {
            "question": "カメラ",
            "options": [
                "sho",
                "Mangga",
                "ji",
                "Kamera"
            ],
            "answer": "Kamera"
        },
        {
            "question": "パソコン",
            "options": [
                "ja",
                "Komputer/Laptop",
                "ma",
                "ge"
            ],
            "answer": "Komputer/Laptop"
        },
        {
            "question": "ホテル",
            "options": [
                "Amerika",
                "kya",
                "bo",
                "Hotel"
            ],
            "answer": "Hotel"
        },
        {
            "question": "レストラン",
            "options": [
                "Korek api",
                "pi",
                "Restoran",
                "Toilet"
            ],
            "answer": "Restoran"
        },
        {
            "question": "コーヒー",
            "options": [
                "ge",
                "Es krim",
                "Kopi",
                "ba"
            ],
            "answer": "Kopi"
        },
        {
            "question": "ケーキ",
            "options": [
                "wo",
                "Kue",
                "ze",
                "bi"
            ],
            "answer": "Kue"
        },
        {
            "question": "トイレ",
            "options": [
                "i",
                "Toilet",
                "Golf",
                "gu"
            ],
            "answer": "Toilet"
        },
        {
            "question": "ベッド",
            "options": [
                "Berita",
                "ka",
                "Tempat tidur",
                "Melon"
            ],
            "answer": "Tempat tidur"
        },
        {
            "question": "シャツ",
            "options": [
                "Kemeja",
                "Hotel",
                "Es krim",
                "ku"
            ],
            "answer": "Kemeja"
        },
        {
            "question": "ネクタイ",
            "options": [
                "ryu",
                "Dasi",
                "no",
                "Tenis"
            ],
            "answer": "Dasi"
        },
        {
            "question": "シューズ",
            "options": [
                "gya",
                "Kopi",
                "so",
                "Sepatu"
            ],
            "answer": "Sepatu"
        },
        {
            "question": "パン",
            "options": [
                "wa",
                "ji",
                "Roti",
                "so"
            ],
            "answer": "Roti"
        },
        {
            "question": "ミルク",
            "options": [
                "Sepak bola",
                "ha",
                "Gitar",
                "Susu"
            ],
            "answer": "Susu"
        },
        {
            "question": "ジュース",
            "options": [
                "Radio",
                "Jus",
                "Kerja paruh waktu",
                "pyo"
            ],
            "answer": "Jus"
        },
        {
            "question": "ビール",
            "options": [
                "Piano",
                "ku",
                "Bir",
                "so"
            ],
            "answer": "Bir"
        },
        {
            "question": "ワイン",
            "options": [
                "jo",
                "me",
                "tsu",
                "Anggur (Minuman)"
            ],
            "answer": "Anggur (Minuman)"
        },
        {
            "question": "サラダ",
            "options": [
                "Berita",
                "yu",
                "Selada",
                "Kamera"
            ],
            "answer": "Selada"
        },
        {
            "question": "スープ",
            "options": [
                "ri",
                "nyo",
                "Sup",
                "cho"
            ],
            "answer": "Sup"
        },
        {
            "question": "ステーキ",
            "options": [
                "be",
                "Kerja paruh waktu",
                "Steak",
                "Korek api"
            ],
            "answer": "Steak"
        },
        {
            "question": "チョコレート",
            "options": [
                "chi",
                "Tenis",
                "wo",
                "Cokelat"
            ],
            "answer": "Cokelat"
        },
        {
            "question": "アイスクリーム",
            "options": [
                "ryu",
                "Manga",
                "Es krim",
                "Televisi"
            ],
            "answer": "Es krim"
        },
        {
            "question": "バナナ",
            "options": [
                "do",
                "Bir",
                "Pisang",
                "go"
            ],
            "answer": "Pisang"
        },
        {
            "question": "オレンジ",
            "options": [
                "gi",
                "mo",
                "ki",
                "Jeruk"
            ],
            "answer": "Jeruk"
        },
        {
            "question": "メロン",
            "options": [
                "Melon",
                "ma",
                "Televisi",
                "ga"
            ],
            "answer": "Melon"
        },
        {
            "question": "マンゴー",
            "options": [
                "ho",
                "Radio",
                "Mangga",
                "ke"
            ],
            "answer": "Mangga"
        },
        {
            "question": "マッチ",
            "options": [
                "ga",
                "Melon",
                "Korek api",
                "ni"
            ],
            "answer": "Korek api"
        },
        {
            "question": "テニス",
            "options": [
                "Televisi",
                "Hotel",
                "Amerika",
                "Tenis"
            ],
            "answer": "Tenis"
        },
        {
            "question": "サッカー",
            "options": [
                "Susu",
                "ka",
                "Sepak bola",
                "nyo"
            ],
            "answer": "Sepak bola"
        },
        {
            "question": "バスケ",
            "options": [
                "Basket",
                "shu",
                "re",
                "Ujian/Tes"
            ],
            "answer": "Basket"
        },
        {
            "question": "ゴルフ",
            "options": [
                "Kerja paruh waktu",
                "i",
                "ga",
                "Golf"
            ],
            "answer": "Golf"
        },
        {
            "question": "スキー",
            "options": [
                "ne",
                "Ski",
                "Sepatu",
                "yu"
            ],
            "answer": "Ski"
        },
        {
            "question": "ピアノ",
            "options": [
                "Korek api",
                "Piano",
                "ze",
                "zu"
            ],
            "answer": "Piano"
        },
        {
            "question": "ギター",
            "options": [
                "pya",
                "Mangga",
                "Dasi",
                "Gitar"
            ],
            "answer": "Gitar"
        },
        {
            "question": "ジャズ",
            "options": [
                "Jazz",
                "wa",
                "pyo",
                "so"
            ],
            "answer": "Jazz"
        },
        {
            "question": "アニメ",
            "options": [
                "no",
                "hya",
                "Amerika",
                "Anime"
            ],
            "answer": "Anime"
        },
        {
            "question": "マンガ",
            "options": [
                "ho",
                "Manga",
                "cho",
                "yo"
            ],
            "answer": "Manga"
        },
        {
            "question": "ゲーム",
            "options": [
                "po",
                "Game",
                "ka",
                "ke"
            ],
            "answer": "Game"
        },
        {
            "question": "ニュース",
            "options": [
                "pa",
                "Berita",
                "fu",
                "ne"
            ],
            "answer": "Berita"
        },
        {
            "question": "アルバイト",
            "options": [
                "Kerja paruh waktu",
                "he",
                "ho",
                "byu"
            ],
            "answer": "Kerja paruh waktu"
        },
        {
            "question": "クラス",
            "options": [
                "Hotel",
                "mi",
                "Kelas",
                "da"
            ],
            "answer": "Kelas"
        },
        {
            "question": "テスト",
            "options": [
                "cha",
                "ha",
                "Ujian/Tes",
                "shu"
            ],
            "answer": "Ujian/Tes"
        },
        {
            "question": "レポート",
            "options": [
                "me",
                "mu",
                "Laporan",
                "ri"
            ],
            "answer": "Laporan"
        },
        {
            "question": "ノート",
            "options": [
                "nyu",
                "Steak",
                "Toilet",
                "Buku catatan"
            ],
            "answer": "Buku catatan"
        }
    ],
    "kanji": [
        {
            "question": "一",
            "options": [
                "Satu",
                "Buku / Asal",
                "Tahun depan",
                "Datang"
            ],
            "answer": "Satu"
        },
        {
            "question": "二",
            "options": [
                "Kiri",
                "Pesawat",
                "Dua",
                "Jauh"
            ],
            "answer": "Dua"
        },
        {
            "question": "三",
            "options": [
                "Empat",
                "Tiga",
                "Lama / Kuno",
                "Harapan"
            ],
            "answer": "Tiga"
        },
        {
            "question": "四",
            "options": [
                "Belakang / Sesudah",
                "Empat",
                "Bawah",
                "Tinggi / Mahal"
            ],
            "answer": "Empat"
        },
        {
            "question": "五",
            "options": [
                "Stasiun",
                "Lima",
                "Sekolah",
                "Sekarang"
            ],
            "answer": "Lima"
        },
        {
            "question": "六",
            "options": [
                "Setiap hari",
                "Enam",
                "Lima",
                "Sedikit"
            ],
            "answer": "Enam"
        },
        {
            "question": "七",
            "options": [
                "Apa",
                "Mendengar",
                "Api",
                "Tujuh"
            ],
            "answer": "Tujuh"
        },
        {
            "question": "八",
            "options": [
                "Lima",
                "Karyawan",
                "Pengalaman",
                "Delapan"
            ],
            "answer": "Delapan"
        },
        {
            "question": "九",
            "options": [
                "Dokter",
                "Bahasa",
                "Harapan",
                "Sembilan"
            ],
            "answer": "Sembilan"
        },
        {
            "question": "十",
            "options": [
                "Sekolah",
                "Bertemu",
                "Sepuluh",
                "Toko buku"
            ],
            "answer": "Sepuluh"
        },
        {
            "question": "百",
            "options": [
                "Orang",
                "Masa kini",
                "Seratus",
                "Usaha/Kerja keras"
            ],
            "answer": "Seratus"
        },
        {
            "question": "千",
            "options": [
                "Seribu",
                "Laki-laki",
                "Masa kini",
                "Emas / Uang"
            ],
            "answer": "Seribu"
        },
        {
            "question": "万",
            "options": [
                "Kereta api",
                "Semangat / Udara",
                "Benci",
                "Sepuluh ribu"
            ],
            "answer": "Sepuluh ribu"
        },
        {
            "question": "円",
            "options": [
                "Yen / Lingkaran",
                "Dalam / Tengah",
                "Perusahaan",
                "Apa"
            ],
            "answer": "Yen / Lingkaran"
        },
        {
            "question": "日",
            "options": [
                "Persiapan",
                "Besar",
                "Hari / Matahari",
                "Penyendiri/Mandiri"
            ],
            "answer": "Hari / Matahari"
        },
        {
            "question": "月",
            "options": [
                "Minggu",
                "Bulan",
                "Kereta api",
                "Masa depan"
            ],
            "answer": "Bulan"
        },
        {
            "question": "火",
            "options": [
                "Belakang / Sesudah",
                "Lemah",
                "Menyetir",
                "Api"
            ],
            "answer": "Api"
        },
        {
            "question": "水",
            "options": [
                "Belajar",
                "Air",
                "Pergi",
                "Kantin"
            ],
            "answer": "Air"
        },
        {
            "question": "木",
            "options": [
                "Menyerah",
                "Langit / Kosong",
                "Api",
                "Pohon"
            ],
            "answer": "Pohon"
        },
        {
            "question": "金",
            "options": [
                "Stasiun",
                "Emas / Uang",
                "Utara",
                "Rendah"
            ],
            "answer": "Emas / Uang"
        },
        {
            "question": "土",
            "options": [
                "Tanah",
                "Lima",
                "Toko buku",
                "Menyetir"
            ],
            "answer": "Tanah"
        },
        {
            "question": "山",
            "options": [
                "Gunung",
                "Panjang / Ketua",
                "Pesawat",
                "Masa kini"
            ],
            "answer": "Gunung"
        },
        {
            "question": "川",
            "options": [
                "Benar / Tepat",
                "Mobil / Kendaraan",
                "Sungai",
                "Listrik"
            ],
            "answer": "Sungai"
        },
        {
            "question": "田",
            "options": [
                "Sawah",
                "Penyendiri/Mandiri",
                "Sepuluh ribu",
                "Rendah"
            ],
            "answer": "Sawah"
        },
        {
            "question": "天",
            "options": [
                "Kecil",
                "Suka",
                "Langit / Surga",
                "Stasiun"
            ],
            "answer": "Langit / Surga"
        },
        {
            "question": "気",
            "options": [
                "Semangat / Udara",
                "Suka",
                "Dalam / Tengah",
                "Keluarga"
            ],
            "answer": "Semangat / Udara"
        },
        {
            "question": "空",
            "options": [
                "Delapan",
                "Toko buku",
                "Suka",
                "Langit / Kosong"
            ],
            "answer": "Langit / Kosong"
        },
        {
            "question": "雨",
            "options": [
                "Hujan",
                "Membaca",
                "Teman",
                "Usaha/Kerja keras"
            ],
            "answer": "Hujan"
        },
        {
            "question": "電",
            "options": [
                "Hari ini",
                "Listrik",
                "Dua",
                "Luar"
            ],
            "answer": "Listrik"
        },
        {
            "question": "車",
            "options": [
                "Minggu",
                "Hari ini",
                "Masa lalu",
                "Mobil / Kendaraan"
            ],
            "answer": "Mobil / Kendaraan"
        },
        {
            "question": "駅",
            "options": [
                "Perusahaan",
                "Belakang / Sesudah",
                "Kebahagiaan",
                "Stasiun"
            ],
            "answer": "Stasiun"
        },
        {
            "question": "前",
            "options": [
                "Kuat",
                "Depan / Sebelum",
                "Orang",
                "Mobil"
            ],
            "answer": "Depan / Sebelum"
        },
        {
            "question": "後",
            "options": [
                "Melihat",
                "Belakang / Sesudah",
                "Jepang",
                "Rendah"
            ],
            "answer": "Belakang / Sesudah"
        },
        {
            "question": "左",
            "options": [
                "Bawah",
                "Kiri",
                "Orang",
                "Benci"
            ],
            "answer": "Kiri"
        },
        {
            "question": "右",
            "options": [
                "Kanan",
                "Impian",
                "Depan / Sebelum",
                "Bahasa"
            ],
            "answer": "Kanan"
        },
        {
            "question": "東",
            "options": [
                "Membeli",
                "Timur",
                "Atas",
                "Bertemu"
            ],
            "answer": "Timur"
        },
        {
            "question": "西",
            "options": [
                "Keluarga",
                "Barat",
                "Delapan",
                "Kekuatan"
            ],
            "answer": "Barat"
        },
        {
            "question": "南",
            "options": [
                "Gunung",
                "Inggris / Unggul",
                "Selatan",
                "Menulis"
            ],
            "answer": "Selatan"
        },
        {
            "question": "北",
            "options": [
                "Sepuluh",
                "Utara",
                "Antara / Durasi",
                "Dekat"
            ],
            "answer": "Utara"
        },
        {
            "question": "口",
            "options": [
                "Air",
                "Siswa",
                "Telepon",
                "Mulut"
            ],
            "answer": "Mulut"
        },
        {
            "question": "目",
            "options": [
                "Liburan/Perjalanan",
                "Mata",
                "Sepuluh ribu",
                "Antara / Durasi"
            ],
            "answer": "Mata"
        },
        {
            "question": "耳",
            "options": [
                "Telinga",
                "Depan / Sebelum",
                "Masa kini",
                "Benar / Tepat"
            ],
            "answer": "Telinga"
        },
        {
            "question": "手",
            "options": [
                "Membeli",
                "Tahun",
                "Tangan",
                "Seribu"
            ],
            "answer": "Tangan"
        },
        {
            "question": "足",
            "options": [
                "Kamar",
                "Kecil",
                "Kaki",
                "Sekarang"
            ],
            "answer": "Kaki"
        },
        {
            "question": "力",
            "options": [
                "Pernikahan",
                "Keluar",
                "Kekuatan",
                "Makan"
            ],
            "answer": "Kekuatan"
        },
        {
            "question": "父",
            "options": [
                "Tahun depan",
                "Perusahaan",
                "Tantangan",
                "Ayah"
            ],
            "answer": "Ayah"
        },
        {
            "question": "母",
            "options": [
                "Lima",
                "Lemah",
                "Ibu",
                "Jepang"
            ],
            "answer": "Ibu"
        },
        {
            "question": "子",
            "options": [
                "Istirahat",
                "Benar / Tepat",
                "Anak",
                "Kanan"
            ],
            "answer": "Anak"
        },
        {
            "question": "男",
            "options": [
                "Bawah",
                "Langit / Kosong",
                "Benar / Tepat",
                "Laki-laki"
            ],
            "answer": "Laki-laki"
        },
        {
            "question": "女",
            "options": [
                "Gunung",
                "Besar",
                "Perempuan",
                "Makan"
            ],
            "answer": "Perempuan"
        },
        {
            "question": "人",
            "options": [
                "Semangat / Udara",
                "Hujan",
                "Tahun lalu",
                "Orang"
            ],
            "answer": "Orang"
        },
        {
            "question": "何",
            "options": [
                "Pengalaman",
                "Tantangan",
                "Apa",
                "Setiap hari"
            ],
            "answer": "Apa"
        },
        {
            "question": "生",
            "options": [
                "Luar",
                "Berbelanja",
                "Hidup / Lahir",
                "Langit / Kosong"
            ],
            "answer": "Hidup / Lahir"
        },
        {
            "question": "学",
            "options": [
                "Pernikahan",
                "Seribu",
                "Belajar / Ilmu",
                "Jauh"
            ],
            "answer": "Belajar / Ilmu"
        },
        {
            "question": "校",
            "options": [
                "Sekolah",
                "Stasiun",
                "Gelap",
                "Masakan"
            ],
            "answer": "Sekolah"
        },
        {
            "question": "先",
            "options": [
                "Membaca",
                "Dahulu / Sedia",
                "Bertemu",
                "Pengalaman"
            ],
            "answer": "Dahulu / Sedia"
        },
        {
            "question": "本",
            "options": [
                "Sekolah",
                "Minum",
                "Buku / Asal",
                "Seratus"
            ],
            "answer": "Buku / Asal"
        },
        {
            "question": "語",
            "options": [
                "Keluarga",
                "Mobil",
                "Bahasa",
                "Sekolah"
            ],
            "answer": "Bahasa"
        },
        {
            "question": "英",
            "options": [
                "Kebahagiaan",
                "Mendengar",
                "Semangat / Udara",
                "Inggris / Unggul"
            ],
            "answer": "Inggris / Unggul"
        },
        {
            "question": "国",
            "options": [
                "Orang",
                "Tujuh",
                "Membaca",
                "Negara"
            ],
            "answer": "Negara"
        },
        {
            "question": "中",
            "options": [
                "Waktu / Jam",
                "Makan",
                "Dalam / Tengah",
                "Jauh"
            ],
            "answer": "Dalam / Tengah"
        },
        {
            "question": "外",
            "options": [
                "Sekolah",
                "Masa lalu",
                "Ibu",
                "Luar"
            ],
            "answer": "Luar"
        },
        {
            "question": "高",
            "options": [
                "Jam",
                "Jalan-jalan",
                "Tinggi / Mahal",
                "Besar"
            ],
            "answer": "Tinggi / Mahal"
        },
        {
            "question": "低",
            "options": [
                "Rendah",
                "Pergi",
                "Tujuh",
                "Bawah"
            ],
            "answer": "Rendah"
        },
        {
            "question": "長",
            "options": [
                "Sembilan",
                "Panjang / Ketua",
                "Mobil / Kendaraan",
                "Mendengar"
            ],
            "answer": "Panjang / Ketua"
        },
        {
            "question": "短",
            "options": [
                "Masa depan",
                "Perusahaan",
                "Pendek",
                "Telepon"
            ],
            "answer": "Pendek"
        },
        {
            "question": "強",
            "options": [
                "Dahulu / Sedia",
                "Kuat",
                "Setiap hari",
                "Stasiun"
            ],
            "answer": "Kuat"
        },
        {
            "question": "弱",
            "options": [
                "Lemah",
                "Mobil / Kendaraan",
                "Baru",
                "Belajar"
            ],
            "answer": "Lemah"
        },
        {
            "question": "大",
            "options": [
                "Besar",
                "Antara / Durasi",
                "Orang",
                "Perempuan"
            ],
            "answer": "Besar"
        },
        {
            "question": "小",
            "options": [
                "Melihat",
                "Dokter",
                "Keluarga",
                "Kecil"
            ],
            "answer": "Kecil"
        },
        {
            "question": "多",
            "options": [
                "Pohon",
                "Dua",
                "Banyak",
                "Luar"
            ],
            "answer": "Banyak"
        },
        {
            "question": "少",
            "options": [
                "Sedikit",
                "Empat",
                "Jalan-jalan",
                "Sekolah"
            ],
            "answer": "Sedikit"
        },
        {
            "question": "新",
            "options": [
                "Belakang / Sesudah",
                "Pendek",
                "Baru",
                "Perusahaan"
            ],
            "answer": "Baru"
        },
        {
            "question": "古",
            "options": [
                "Telinga",
                "Melihat",
                "Lama / Kuno",
                "Tahun depan"
            ],
            "answer": "Lama / Kuno"
        },
        {
            "question": "正",
            "options": [
                "Pohon",
                "Benar / Tepat",
                "Delapan",
                "Menulis"
            ],
            "answer": "Benar / Tepat"
        },
        {
            "question": "近",
            "options": [
                "Pesawat",
                "Dekat",
                "Lemah",
                "Luar"
            ],
            "answer": "Dekat"
        },
        {
            "question": "遠",
            "options": [
                "Lima",
                "Jauh",
                "Menyetir",
                "Kebahagiaan"
            ],
            "answer": "Jauh"
        },
        {
            "question": "明",
            "options": [
                "Setiap hari",
                "Laki-laki",
                "Terang",
                "Sedikit"
            ],
            "answer": "Terang"
        },
        {
            "question": "暗",
            "options": [
                "Pekerjaan",
                "Rumah sakit",
                "Gelap",
                "Api"
            ],
            "answer": "Gelap"
        },
        {
            "question": "上",
            "options": [
                "Atas",
                "Masa depan",
                "Suka",
                "Belajar"
            ],
            "answer": "Atas"
        },
        {
            "question": "下",
            "options": [
                "Dokter",
                "Belajar",
                "Sawah",
                "Bawah"
            ],
            "answer": "Bawah"
        },
        {
            "question": "内",
            "options": [
                "Kecil",
                "Dalam / Internal",
                "Depan / Sebelum",
                "Menyerah"
            ],
            "answer": "Dalam / Internal"
        },
        {
            "question": "好",
            "options": [
                "Atas",
                "Langit / Kosong",
                "Suka",
                "Sedikit"
            ],
            "answer": "Suka"
        },
        {
            "question": "嫌",
            "options": [
                "Semangat / Udara",
                "Sekolah",
                "Benci",
                "Belajar"
            ],
            "answer": "Benci"
        },
        {
            "question": "食",
            "options": [
                "Pergi",
                "Makan",
                "Perusahaan",
                "Dalam / Internal"
            ],
            "answer": "Makan"
        },
        {
            "question": "飲",
            "options": [
                "Bertemu",
                "Dekat",
                "Teman",
                "Minum"
            ],
            "answer": "Minum"
        },
        {
            "question": "見",
            "options": [
                "Melihat",
                "Belajar",
                "Timur",
                "Pengalaman"
            ],
            "answer": "Melihat"
        },
        {
            "question": "聞",
            "options": [
                "Mendengar",
                "Kanan",
                "Persiapan",
                "Hidup / Lahir"
            ],
            "answer": "Mendengar"
        },
        {
            "question": "書",
            "options": [
                "Keluar",
                "Jam",
                "Kecil",
                "Menulis"
            ],
            "answer": "Menulis"
        },
        {
            "question": "読",
            "options": [
                "Membaca",
                "Masa lalu",
                "Ayah",
                "Bandara"
            ],
            "answer": "Membaca"
        },
        {
            "question": "話",
            "options": [
                "Panjang / Ketua",
                "Persiapan",
                "Berbicara",
                "Gunung"
            ],
            "answer": "Berbicara"
        },
        {
            "question": "買",
            "options": [
                "Ayah",
                "Membeli",
                "Berbicara",
                "Berbelanja"
            ],
            "answer": "Membeli"
        },
        {
            "question": "行",
            "options": [
                "Tangan",
                "Pergi",
                "Penyendiri/Mandiri",
                "Toko buku"
            ],
            "answer": "Pergi"
        },
        {
            "question": "来",
            "options": [
                "Kantin",
                "Sekolah",
                "Kuat",
                "Datang"
            ],
            "answer": "Datang"
        },
        {
            "question": "出",
            "options": [
                "Hujan",
                "Keluar",
                "Air",
                "Sepuluh"
            ],
            "answer": "Keluar"
        },
        {
            "question": "入",
            "options": [
                "Masuk",
                "Sepuluh ribu",
                "Baru",
                "Utara"
            ],
            "answer": "Masuk"
        },
        {
            "question": "会",
            "options": [
                "Seribu",
                "Bertemu",
                "Benar / Tepat",
                "Dekat"
            ],
            "answer": "Bertemu"
        },
        {
            "question": "社",
            "options": [
                "Besok",
                "Belajar",
                "Perusahaan",
                "Apa"
            ],
            "answer": "Perusahaan"
        },
        {
            "question": "休",
            "options": [
                "Penyendiri/Mandiri",
                "Istirahat",
                "Sepuluh ribu",
                "Dua"
            ],
            "answer": "Istirahat"
        },
        {
            "question": "時",
            "options": [
                "Kereta api",
                "Lima",
                "Guru",
                "Waktu / Jam"
            ],
            "answer": "Waktu / Jam"
        },
        {
            "question": "間",
            "options": [
                "Antara / Durasi",
                "Benci",
                "Sungai",
                "Lemah"
            ],
            "answer": "Antara / Durasi"
        },
        {
            "question": "週",
            "options": [
                "Harapan",
                "Minggu",
                "Antara / Durasi",
                "Buku / Asal"
            ],
            "answer": "Minggu"
        },
        {
            "question": "年",
            "options": [
                "Tahun",
                "Anak",
                "Empat",
                "Kiri"
            ],
            "answer": "Tahun"
        },
        {
            "question": "今",
            "options": [
                "Hujan",
                "Masa lalu",
                "Sekarang",
                "Istirahat"
            ],
            "answer": "Sekarang"
        },
        {
            "question": "今日",
            "options": [
                "Dalam / Internal",
                "Hari ini",
                "Sedikit",
                "Yen / Lingkaran"
            ],
            "answer": "Hari ini"
        },
        {
            "question": "明日",
            "options": [
                "Negara",
                "Tangan",
                "Besok",
                "Tahun"
            ],
            "answer": "Besok"
        },
        {
            "question": "毎日",
            "options": [
                "Pohon",
                "Persiapan",
                "Setiap hari",
                "Kereta api"
            ],
            "answer": "Setiap hari"
        },
        {
            "question": "去年",
            "options": [
                "Tahun lalu",
                "Air",
                "Belakang / Sesudah",
                "Masuk"
            ],
            "answer": "Tahun lalu"
        },
        {
            "question": "来年",
            "options": [
                "Langit / Surga",
                "Tangan",
                "Panjang / Ketua",
                "Tahun depan"
            ],
            "answer": "Tahun depan"
        },
        {
            "question": "日本",
            "options": [
                "Listrik",
                "Melihat",
                "Jepang",
                "Langit / Kosong"
            ],
            "answer": "Jepang"
        },
        {
            "question": "先生",
            "options": [
                "Guru",
                "Mobil",
                "Menulis",
                "Menyerah"
            ],
            "answer": "Guru"
        },
        {
            "question": "学生",
            "options": [
                "Seratus",
                "Hari / Matahari",
                "Api",
                "Siswa"
            ],
            "answer": "Siswa"
        },
        {
            "question": "学校",
            "options": [
                "Semangat / Udara",
                "Sekolah",
                "Bertemu",
                "Sepuluh"
            ],
            "answer": "Sekolah"
        },
        {
            "question": "会社",
            "options": [
                "Hidup / Lahir",
                "Sungai",
                "Perusahaan",
                "Pekerjaan"
            ],
            "answer": "Perusahaan"
        },
        {
            "question": "社員",
            "options": [
                "Kebebasan",
                "Emas / Uang",
                "Karyawan",
                "Tahun"
            ],
            "answer": "Karyawan"
        },
        {
            "question": "友達",
            "options": [
                "Keluar",
                "Masa depan",
                "Teman",
                "Rendah"
            ],
            "answer": "Teman"
        },
        {
            "question": "家族",
            "options": [
                "Keluarga",
                "Kuat",
                "Dalam / Tengah",
                "Hari / Matahari"
            ],
            "answer": "Keluarga"
        },
        {
            "question": "時計",
            "options": [
                "Hujan",
                "Buku / Asal",
                "Luar",
                "Jam"
            ],
            "answer": "Jam"
        },
        {
            "question": "電話",
            "options": [
                "Telepon",
                "Kaki",
                "Harapan",
                "Negara"
            ],
            "answer": "Telepon"
        },
        {
            "question": "部屋",
            "options": [
                "Kamar",
                "Usaha/Kerja keras",
                "Belajar",
                "Masuk"
            ],
            "answer": "Kamar"
        },
        {
            "question": "電車",
            "options": [
                "Waktu / Jam",
                "Hujan",
                "Ibu",
                "Kereta api"
            ],
            "answer": "Kereta api"
        },
        {
            "question": "自動車",
            "options": [
                "Buku / Asal",
                "Jalan-jalan",
                "Mobil",
                "Kanan"
            ],
            "answer": "Mobil"
        },
        {
            "question": "飛行機",
            "options": [
                "Perempuan",
                "Pesawat",
                "Panjang / Ketua",
                "Utara"
            ],
            "answer": "Pesawat"
        },
        {
            "question": "空港",
            "options": [
                "Bandara",
                "Rumah sakit",
                "Toko buku",
                "Sedikit"
            ],
            "answer": "Bandara"
        },
        {
            "question": "病院",
            "options": [
                "Luar",
                "Minggu",
                "Delapan",
                "Rumah sakit"
            ],
            "answer": "Rumah sakit"
        },
        {
            "question": "医者",
            "options": [
                "Pohon",
                "Tiga",
                "Dokter",
                "Api"
            ],
            "answer": "Dokter"
        },
        {
            "question": "本屋",
            "options": [
                "Jalan-jalan",
                "Sepuluh ribu",
                "Seratus",
                "Toko buku"
            ],
            "answer": "Toko buku"
        },
        {
            "question": "食堂",
            "options": [
                "Air",
                "Panjang / Ketua",
                "Penyendiri/Mandiri",
                "Kantin"
            ],
            "answer": "Kantin"
        },
        {
            "question": "料理",
            "options": [
                "Telepon",
                "Rendah",
                "Kamar",
                "Masakan"
            ],
            "answer": "Masakan"
        },
        {
            "question": "勉強",
            "options": [
                "Telepon",
                "Belakang / Sesudah",
                "Belajar",
                "Terang"
            ],
            "answer": "Belajar"
        },
        {
            "question": "仕事",
            "options": [
                "Mulut",
                "Sekolah",
                "Pekerjaan",
                "Dua"
            ],
            "answer": "Pekerjaan"
        },
        {
            "question": "旅行",
            "options": [
                "Liburan/Perjalanan",
                "Benar / Tepat",
                "Buku / Asal",
                "Besar"
            ],
            "answer": "Liburan/Perjalanan"
        },
        {
            "question": "散歩",
            "options": [
                "Dalam / Internal",
                "Jalan-jalan",
                "Dahulu / Sedia",
                "Api"
            ],
            "answer": "Jalan-jalan"
        },
        {
            "question": "運転",
            "options": [
                "Rumah sakit",
                "Sungai",
                "Ibu",
                "Menyetir"
            ],
            "answer": "Menyetir"
        },
        {
            "question": "買い物",
            "options": [
                "Melihat",
                "Sekarang",
                "Berbelanja",
                "Langit / Surga"
            ],
            "answer": "Berbelanja"
        },
        {
            "question": "結婚",
            "options": [
                "Rendah",
                "Pernikahan",
                "Delapan",
                "Makan"
            ],
            "answer": "Pernikahan"
        },
        {
            "question": "準備",
            "options": [
                "Persiapan",
                "Bertemu",
                "Benci",
                "Inggris / Unggul"
            ],
            "answer": "Persiapan"
        },
        {
            "question": "経験",
            "options": [
                "Pekerjaan",
                "Empat",
                "Pengalaman",
                "Benci"
            ],
            "answer": "Pengalaman"
        },
        {
            "question": "孤高",
            "options": [
                "Sawah",
                "Buku / Asal",
                "Terang",
                "Penyendiri/Mandiri"
            ],
            "answer": "Penyendiri/Mandiri"
        },
        {
            "question": "諦める",
            "options": [
                "Menyerah",
                "Telepon",
                "Negara",
                "Berbicara"
            ],
            "answer": "Menyerah"
        },
        {
            "question": "挑戦",
            "options": [
                "Tantangan",
                "Suka",
                "Tahun",
                "Yen / Lingkaran"
            ],
            "answer": "Tantangan"
        },
        {
            "question": "夢",
            "options": [
                "Impian",
                "Dekat",
                "Besar",
                "Pergi"
            ],
            "answer": "Impian"
        },
        {
            "question": "未来",
            "options": [
                "Suka",
                "Tahun depan",
                "Masa depan",
                "Belakang / Sesudah"
            ],
            "answer": "Masa depan"
        },
        {
            "question": "過去",
            "options": [
                "Suka",
                "Masa lalu",
                "Telinga",
                "Banyak"
            ],
            "answer": "Masa lalu"
        },
        {
            "question": "現在",
            "options": [
                "Mobil / Kendaraan",
                "Tujuh",
                "Masa kini",
                "Sepuluh ribu"
            ],
            "answer": "Masa kini"
        },
        {
            "question": "平和",
            "options": [
                "Kedamaian",
                "Sekolah",
                "Terang",
                "Lama / Kuno"
            ],
            "answer": "Kedamaian"
        },
        {
            "question": "幸福",
            "options": [
                "Dahulu / Sedia",
                "Pohon",
                "Atas",
                "Kebahagiaan"
            ],
            "answer": "Kebahagiaan"
        },
        {
            "question": "自由",
            "options": [
                "Penyendiri/Mandiri",
                "Jauh",
                "Kebebasan",
                "Istirahat"
            ],
            "answer": "Kebebasan"
        },
        {
            "question": "希望",
            "options": [
                "Semangat / Udara",
                "Timur",
                "Harapan",
                "Yen / Lingkaran"
            ],
            "answer": "Harapan"
        },
        {
            "question": "努力",
            "options": [
                "Tantangan",
                "Rumah sakit",
                "Enam",
                "Usaha/Kerja keras"
            ],
            "answer": "Usaha/Kerja keras"
        }
    ]
};

// =========================================
// VARIABEL STATE APLIKASI
// =========================================
let currentCategory = '';
let currentQuestions = [];
let currentQuestionIndex = 0;
let score = 0;

// =========================================
// ELEMEN UI HTML
// =========================================
const screens = {
    home: document.getElementById('home-screen'),
    quiz: document.getElementById('quiz-screen'),
    result: document.getElementById('result-screen')
};

const ui = {
    categoryCards: document.querySelectorAll('.category-card'),
    categoryLabel: document.getElementById('current-category-label'),
    scoreDisplay: document.getElementById('score-display'),
    currentQNum: document.getElementById('current-q-num'),
    totalQNum: document.getElementById('total-q-num'),
    progressBar: document.getElementById('progress-bar-fill'),
    questionText: document.getElementById('main-question-text'),
    answerButtons: document.getElementById('answer-buttons'),
    finalScore: document.getElementById('final-score'),
    accuracyPercent: document.getElementById('accuracy-percent'),
    resultFeedback: document.getElementById('result-feedback'),
    btnRetry: document.getElementById('btn-retry'),
    btnHome: document.getElementById('btn-home')
};

// =========================================
// LOGIKA GAME ENGINE
// =========================================
function showScreen(screenName) {
    Object.values(screens).forEach(screen => {
        screen.classList.remove('active-screen');
        screen.classList.add('hidden');
    });
    screens[screenName].classList.remove('hidden');
    screens[screenName].classList.add('active-screen');
}

ui.categoryCards.forEach(card => {
    card.addEventListener('click', () => {
        currentCategory = card.getAttribute('data-category');
        startQuiz();
    });
});

function startQuiz() {
    // Mengambil 150 soal penuh berurutan sesuai kategori yang dipilih
    currentQuestions = [...quizData[currentCategory]];
    currentQuestionIndex = 0;
    score = 0;
    
    ui.categoryLabel.textContent = currentCategory.charAt(0).toUpperCase() + currentCategory.slice(1);
    ui.totalQNum.textContent = currentQuestions.length;
    ui.scoreDisplay.textContent = score;
    
    showScreen('quiz');
    loadQuestion();
}

function loadQuestion() {
    const currentQ = currentQuestions[currentQuestionIndex];
    
    ui.currentQNum.textContent = currentQuestionIndex + 1;
    const progressPercent = (currentQuestionIndex / currentQuestions.length) * 100;
    ui.progressBar.style.width = `${progressPercent}%`;
    ui.questionText.textContent = currentQ.question;
    
    ui.answerButtons.innerHTML = '';
    
    currentQ.options.forEach(option => {
        const button = document.createElement('button');
        button.classList.add('btn-answer');
        button.textContent = option;
        button.addEventListener('click', () => checkAnswer(button, currentQ.answer));
        ui.answerButtons.appendChild(button);
    });
}

function checkAnswer(selectedButton, correctAnswer) {
    const allButtons = ui.answerButtons.querySelectorAll('.btn-answer');
    allButtons.forEach(btn => btn.disabled = true);
    
    if (selectedButton.textContent === correctAnswer) {
        selectedButton.classList.add('correct');
        score += 10;
        ui.scoreDisplay.textContent = score;
    } else {
        selectedButton.classList.add('wrong');
        allButtons.forEach(btn => {
            if (btn.textContent === correctAnswer) {
                btn.classList.add('correct');
            }
        });
    }
    
    setTimeout(() => {
        currentQuestionIndex++;
        if (currentQuestionIndex < currentQuestions.length) {
            loadQuestion();
        } else {
            showResults();
        }
    }, 600);
}

function showResults() {
    ui.progressBar.style.width = '100%';
    const maxScore = currentQuestions.length * 10;
    const accuracy = Math.round((score / maxScore) * 100);
    
    ui.finalScore.textContent = score;
    ui.accuracyPercent.textContent = `${accuracy}%`;
    
    if (accuracy === 100) {
        ui.resultFeedback.textContent = "Luar Biasa Sempurna! Kamu Menguasai 150 Soal Penuh Kategori Ini!";
    } else if (accuracy >= 70) {
        ui.resultFeedback.textContent = "Hebat! Skor tinggi berhasil dicapai. Tingkatkan terus!";
    } else {
        ui.resultFeedback.textContent = "Jangan menyerah! Terus berlatih menuju target N2!";
    }
    
    setTimeout(() => {
        showScreen('result');
    }, 400);
}

ui.btnRetry.addEventListener('click', startQuiz);
ui.btnHome.addEventListener('click', () => {
    showScreen('home');
    ui.progressBar.style.width = '0%';
});
